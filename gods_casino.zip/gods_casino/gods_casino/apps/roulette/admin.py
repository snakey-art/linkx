from django.contrib import admin
from .models import *

admin.site.register(Card)
admin.site.register(Round)
admin.site.register(Ticket)
admin.site.register(Player)
admin.site.register(Waiting)
