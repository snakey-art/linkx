from django.shortcuts import render, redirect
from .models import *
from django.http import Http404, HttpResponseRedirect, HttpResponse
from django.urls import reverse
import requests
import json

API_KEY = '3da551a4-ae01-4cfc-abc7-2d686fee3e7f' #HIDE
TAX = 1.05 #HIDE


def index(request):
	try:
		cookie = request.COOKIES['a']
		active_rounds = Round.objects.filter(round_active = True)
		history_rounds = Round.objects.filter(round_active = False).order_by('-id')[:10]
		return render(request, 'roulette/list.html', 
			{'active_rounds': active_rounds, 'cookie': cookie, 'history_rounds': history_rounds})
	except:
		return render(request, 'roulette/auth.html')

def payments(request):
	payments_rounds = Round.objects.filter(round_active = False, round_transfer_proof = "None")
	return render(request, 'roulette/payments.html', {'payments_rounds': payments_rounds})

def problems(request):
	problems_waiters = Waiting.objects.filter(waiting_is_problem = True)
	return render(request, 'roulette/problems.html', {'problems_waiters': problems_waiters})


def find_card_in_bot(card_nft_number):
	bot_address = "0xb27245E78d66A08BD1FEE8BCA1988889d43556C3" #HIDE
	headers = {"Accept": "application/json"}
	url = "https://api.x.immutable.com/v1/assets?collection=0xacb3c6a43d15b907e8433077b6d38ae40936fe2c&user={0}&status=imx".format(bot_address)
	response = requests.request("GET", url, headers=headers)
	for card in response.json()['result']:
		if (card_nft_number == card['token_id']):
			return True
	return False


def go_auth(request):
	try:
		cookie = request.COOKIES['a']
		return render(request, 'roulette/authed.html', {'cookie': cookie})
	except:	
		return render(request, 'roulette/auth.html')


def doauth(request):
	try:
		cookie = request.POST['inputAcc']
		refferer = request.POST['refferer']
		user_verification(cookie, refferer)
		return index(request)
	except:
		raise Http404("DOAUTH Except raised")


def user_verification(cookie, refferer):
	player = Player.objects.filter(player_metamask_address = cookie)
	if len(player) == 0:
		reff = Player.objects.filter(player_metamask_address = refferer)
		if len(reff) == 0:
			new_player = Player(player_id = gen_player_id(), player_metamask_address = cookie, 
				player_refferer = '0x0')
		else:
			new_player = Player(player_id = gen_player_id(), player_metamask_address = cookie, 
				player_refferer = refferer)
		new_player.save()


def gen_player_id():
	return Player.objects.count() + 1


def detail(request, round_id):
	try:
		cookie= request.COOKIES['a']
		round = Round.objects.get(round_id = round_id)
		round_tickets = Ticket.objects.filter(ticket_round = round)
	except:
		return render(request, 'roulette/auth.html')
	return render(request, 'roulette/detail.html', {'round': round, 'round_tickets': round_tickets, 
		'cookie': cookie})


def finish_round(round):
	raw_data = {
	"jsonrpc": "2.0",
	"method": "generateSignedIntegers",
	"params": {
		"apiKey": API_KEY,
		"n": 1,
		"min": 1,
		"max": round.round_num_tickets,
		"replacement": True
	},
	'id':1
	}
	headers = {'Content-type': 'application/json','Content-Length': '200', 'Accept': 'application/json'}
	data = json.dumps(raw_data)
	response = requests.post(
		url='https://api.random.org/json-rpc/2/invoke',
		data=data,
		headers=headers
		)
	a = response.text.split('random\":')[1]
	b = a.split(',\"signature\":\"')
	c = b[1].split('\",\"bits')[0]
	round.round_proof_result = response.json()['result']['random']['data'][0]
	round.round_proof_random = b[0]
	round.round_proof_signature = c
	winner_ticket = Ticket.objects.get(ticket_round = round, ticket_number = int(round.round_proof_result))
	winner_ticket.ticket_won = True
	round.round_winner = winner_ticket.ticket_owner
	round.round_active = False
	winner = winner_ticket.ticket_owner
	winner.player_total_wins += 1
	round.save()
	winner_ticket.save()
	winner.save()


def check_round_active(round):
	if (round.round_tickets_bought == round.round_num_tickets):
		if round.round_active == True:
			finish_round(round)


def buy_ticket_start_waiting(ticket_id, cookie, token):
	waiter = Waiting(waiting_from = cookie, waiting_for_ticket_id = ticket_id, waiting_token = token, 
		waiting_amount = 999)
	ticket = Ticket.objects.get(ticket_id = ticket_id)
	if (token == 'eth'):
		waiter.waiting_amount = ticket.ticket_price_eth
	if (token == 'gods'):
		waiter.waiting_amount = ticket.ticket_price_gods
	waiter.save()
	player = Player.objects.get(player_metamask_address = cookie)
	player.player_buying_ticket = True
	player.player_buying_ticket_id = ticket_id
	player.save()


def show_waiter_to_player(request, cookie):
	player = Player.objects.get(player_metamask_address = cookie)
	ticket = Ticket.objects.get(ticket_id = player.player_buying_ticket_id)
	waiter = Waiting.objects.get(waiting_from = cookie)
	return render(request, 'roulette/buying.html', {'ticket': ticket, 'cookie': cookie, 'cancel': True, 'waiter': waiter})


def buy_ticket_cancel_by_player(request):
	try:
		cookie = request.COOKIES['a']
		player = Player.objects.get(player_metamask_address = cookie)
		waiter = Waiting.objects.get(waiting_from = cookie)
		waiter.delete()
		player.player_buying_ticket = False
		player.player_buying_ticket_id = 0
		player.save()
		return index(request)
	except:
		return render(request, 'roulette/auth.html')


def waiting_stop_success(ticket_id):
	waiter = Waiting.objects.get(waiting_for_ticket_id = ticket_id)
	player = Player.objects.get(player_metamask_address = waiter.waiting_from)
	refferer = Player.objects.get(player_metamask_address = player.player_refferer)
	ticket = Ticket.objects.get(ticket_id = ticket_id)
	round = ticket.ticket_round
	if ticket.ticket_owner == "0x0":
		waiter.delete()
		ticket.ticket_owner = player
		ticket.save()
		player.player_buying_ticket = False
		player.player_total_tickets += 1
		player.player_tickets_before_last_giveaway += 1
		player.save()
		refferer.player_refferal_tickets_before_last_giveaway += 1
		refferer.save()
		round.round_tickets_bought += 1
		round.save()
		check_round_active(round)
	else:
		waiter.waiting_is_problem = True
		waiter.waiting_from = player.player_metamask_address[2:]
		player.player_buying_ticket = False
		waiter.save()
		player.save()

def buy_ticket_check_waiter(ticket_id):
	waiter = Waiting.objects.get(waiting_for_ticket_id = ticket_id)
	time_raw = str(waiter.waiting_timestamp)
	time_good = ''
	for i in range(len(time_raw)):
		if time_raw[i] == ' ':
			time_good += 'T'
			continue
		if time_raw[i] == '+':
			time_good += 'Z'
			break
		time_good += time_raw[i]
	url = 'https://api.x.immutable.com/v1/transfers?'
	user = waiter.waiting_from
	receiver = '0xb27245E78d66A08BD1FEE8BCA1988889d43556C3' #HIDE
	if (waiter.waiting_token == 'gods'):
		token_type = 'ERC20&token_address=0xccc8cb5229b0ac8069c51fd58367fd1e622afd97'
	else:
		token_type = 'ETH'
	full = '{0}user={1}&receiver={2}&status=success&min_timestamp={3}&token_type={4}'.format(url, user, 
		receiver, time_good, token_type)
	headers = {"Accept": "application/json"}
	response = requests.request("GET", full, headers=headers)
	transaction_cheker = len(response.json()['result'])
	if (transaction_cheker != 0):
		quantity = float(response.json()['result'][0]['token']['data']['quantity'])
		quantity /= 1000000000000000000
		ticket = Ticket.objects.get(ticket_id = ticket_id)
		if (waiter.waiting_token == 'gods'):
			if(quantity == ticket.ticket_price_gods):
				waiting_stop_success(ticket_id)
		if (waiter.waiting_token == 'ETH'):
			if(quantity == ticket.ticket_price_eth):
				waiting_stop_success(ticket_id)


def buy_ticket(request, ticket_id):
	try:
		cookie = request.COOKIES['a']
		ticket = Ticket.objects.get(ticket_id = ticket_id)
		token = request.POST['token']
		round = ticket.ticket_round
		player = Player.objects.get(player_metamask_address = cookie)
	except:
		return render(request, 'roulette/auth.html')
	try:
		if (ticket.ticket_owner.player_metamask_address == '0x0'):
			if (player.player_buying_ticket):
				return show_waiter_to_player(request, cookie)
			buy_ticket_start_waiting(ticket_id, cookie, token)
		else:
			raise Http404("TICKET BOUGHT ALREADY!")
	except:
		raise Http404("BUY TICKET 2 Except raised: token {0}".format(token))
	return redirect('http://gu-roulette.com:3000/?sym={0}&am={1}'.format(Waiting.objects.get(waiting_from = cookie).waiting_token, Waiting.objects.get(waiting_from = cookie).waiting_amount))


def round_generator(request):
	return render(request, 'roulette/generator.html')


def generate(request):
	generator_card_nft_number = request.POST['card_id']
	generator_tickets_num = request.POST['tickets_number']
	if find_card_in_bot(generator_card_nft_number):
		headers = {"Accept": "application/json"}
		null_player = Player.objects.get(player_id = 2)
		base_url = "https://api.x.immutable.com/v1/assets/0xacb3c6a43d15b907e8433077b6d38ae40936fe2c/"
		r = requests.request("GET", '{0}{1}'.format(base_url, generator_card_nft_number), headers=headers)
		new_card = Card(card_name = parse_card_name(r), card_nft_number = generator_card_nft_number, 
			card_proto = parse_card_proto(r), card_quality = parse_card_quality(r), 
			card_price_eth = parse_card_price_eth(r), 
			card_price_gods = parse_card_price_gods(r), 
			card_price_dollar = parse_card_price_dollar(r),
			card_img_link = parse_card_img_link(r))
		new_round = Round(round_card = new_card, round_id = gen_round_id(), round_num_tickets = generator_tickets_num, 
			round_tickets_bought = 0, round_winner = null_player, round_active = True, 
			round_proof_result = 0, round_proof_random = "", round_proof_signature = "", 
			round_name = str(gen_round_id()))
		new_tickets = []
		for x in range(int(generator_tickets_num)):
			new_ticket = Ticket(ticket_id = (gen_ticket_id() + 1 + x), 
				ticket_owner = null_player, ticket_round = new_round, ticket_number = (x+1), 
				ticket_price_gods = get_ticket_price_gods(new_round), 
				ticket_price_eth = get_ticket_price_eth(new_round), ticket_won = False)
			new_tickets.append(new_ticket)
		new_card.save()
		new_round.save()
		for x in range(int(generator_tickets_num)):
			new_tickets[x].save()
		return HttpResponseRedirect(reverse('detail', args=[new_round.round_id]))
	else:
		return HttpResponseRedirect(reverse('round_generator'))


def check_payment(request):
	try:
		cookie = request.COOKIES['a']
		player = Player.objects.get(player_metamask_address = cookie)
		if (player.player_buying_ticket):
			ticket = Ticket.objects.get(ticket_id = player.player_buying_ticket_id)
			buy_ticket_check_waiter(ticket.ticket_id)
			return render(request, 'roulette/check.html', {'ok': False, 'cookie': cookie})
		return render(request, 'roulette/check.html', {'ok': True, 'cookie': cookie})
	except:
		return render(request, 'roulette/auth.html')


def parse_card_name(r):
	return r.json()['name']


def parse_card_price_gods(r):
	u1 = 'https://api.x.immutable.com/v1/orders?buy_token_type=ERC20&direction=asc&include_fees=false&order_by=buy_quantity&sell_metadata={"proto":["'
	u2 = '"],"quality":["'
	u3 = '"]}&sell_token_address=0xacb3c6a43d15b907e8433077b6d38ae40936fe2c&buy_token_address=0xccc8cb5229b0ac8069c51fd58367fd1e622afd97&status=active'
	rf = requests.request('GET', u1 + str(parse_card_proto(r)) + u2 + parse_card_quality_raw(r) + u3)
	p1 = float(rf.json()['result'][0]['buy']['data']['quantity'])
	p2 = float(rf.json()['result'][1]['buy']['data']['quantity'])
	p1 /= 1000000000000000000
	p2 /= 1000000000000000000
	p = (p1 + p2) / 2
	return round(p, 2)


def parse_card_price_eth(r):
	u1 = 'https://api.x.immutable.com/v1/orders?buy_token_type=eth&direction=asc&include_fees=false&order_by=buy_quantity&sell_metadata={"proto":["'
	u2 = '"],"quality":["'
	u3 = '"]}&sell_token_address=0xacb3c6a43d15b907e8433077b6d38ae40936fe2c&status=active'
	rf = requests.request('GET', u1 + str(parse_card_proto(r)) + u2 + parse_card_quality_raw(r) + u3)
	p1 = float(rf.json()['result'][0]['buy']['data']['quantity'])
	p2 = float(rf.json()['result'][1]['buy']['data']['quantity'])
	p1 /= 1000000000000000000
	p2 /= 1000000000000000000
	p = (p1 + p2) / 2
	return round(p, 5)


def parse_card_price_dollar(r):
	rf = requests.request('GET', 
		"https://api.coingecko.com/api/v3/simple/price?ids=gods-unchained,ethereum&vs_currencies=usd")
	g = parse_card_price_gods(r)
	e = parse_card_price_eth(r)
	rg = (float(rf.json()['gods-unchained']['usd']) * g)
	re = (float(rf.json()['ethereum']['usd']) * e)
	return round(((rg + re) / 2), 2)


def parse_card_img_link(r):
	proto = str(parse_card_proto(r))
	quality = str(parse_card_quality(r))
	u1 = 'https://card.godsunchained.com/?id='
	u2 = '&q='
	return (u1 + proto + u2 + quality)


def parse_card_quality(r):
	res = r.json()['metadata']['quality']
	if(res == "Meteorite"):
		return 4
	if(res == "Shadow"):
		return 3
	if(res == "Gold"):
		return 2
	if(res == "Diamond"):
		return 1
	return 0


def parse_card_quality_raw(r):
	return r.json()['metadata']['quality']


def parse_card_proto(r):
	return r.json()['metadata']['proto']


def gen_round_id():
	count = Round.objects.count()
	return int(count + 1)


def gen_ticket_id():
	return Ticket.objects.count()


def get_ticket_price_gods(rround):
	card_price = rround.round_card.card_price_gods
	ticket_price = float(card_price) / float(rround.round_num_tickets)
	ticket_price *= TAX
	return round(ticket_price, 2)


def get_ticket_price_eth(rround):
	card_price = rround.round_card.card_price_eth
	ticket_price = float(card_price) / float(rround.round_num_tickets)
	ticket_price *= TAX
	return round(ticket_price, 5)