from django.urls import path
from . import views

urlpatterns = [
	path('', views.go_auth, name = 'go_auth'),
	path('roulette/', views.index, name = 'index'),
	path('<int:round_id>/', views.detail, name = 'detail'),
	path('buy_ticket/<int:ticket_id>/', views.buy_ticket, name = 'buy_ticket'),
	path('generator/', views.round_generator, name = 'round_generator'),
	path('generator/generate/', views.generate, name = 'generate'),
	path('doauth/', views.doauth, name = 'doauth'),
	path('cancel/', views.buy_ticket_cancel_by_player, name='buy_ticket_cancel_by_player'),
	path('check_payment/', views.check_payment, name='check_payment'),
	path('problems/', views.problems, name='problems'),
	path('payments/', views.payments, name='payments'),
]
