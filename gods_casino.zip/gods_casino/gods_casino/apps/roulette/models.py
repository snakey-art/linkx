from django.db import models


class Waiting(models.Model):
	waiting_from = models.CharField('Waiting from', max_length = 100)
	waiting_for_ticket_id = models.IntegerField('Ticket id')
	waiting_token = models.CharField('GODS OR ETH', max_length = 100)
	waiting_amount = models.FloatField('Ticket cost', default = 999)
	waiting_timestamp = models.DateTimeField(auto_now=False, auto_now_add=True)
	waiting_is_problem = models.BooleanField('Is this probleme?', default = False)

	def __str__(self):
		return 'Waiting for ticket id {0}'.format(str(self.waiting_for_ticket_id))


class Player(models.Model):
	player_id = models.IntegerField('Player id')
	player_metamask_address = models.CharField('Metamask address', max_length = 100)
	player_refferer = models.CharField('Player`s refferer', max_length = 100, default = "0x0")
	player_total_tickets = models.IntegerField('Player total tickets', default = 0)
	player_tickets_before_last_giveaway = models.IntegerField('Player tickets before last giveaway', default = 0)
	player_refferal_tickets_before_last_giveaway = models.IntegerField('Refferal`s tickets before last giveaway', 
		default = 0)
	player_total_wins = models.IntegerField('Player total wins', default = 0)
	player_buying_ticket = models.BooleanField('Trying to buy ticket now', default = False)
	player_buying_ticket_id = models.IntegerField('Ticket id trying to buy', default = 0)

	def __str__(self):
		return '{0}{1}{2}{3}'.format(str(self.player_id), " (", str(self.player_total_tickets), ")")

class Card(models.Model):
	card_name = models.CharField('Card name', max_length = 100)
	card_nft_number = models.CharField('Card NFT number', max_length = 100)
	card_proto = models.IntegerField('Card proto')
	card_quality = models.CharField('Card quality', max_length = 100, default = "Meteorite")
	card_price_eth = models.FloatField('Card price ETH', default = 999)
	card_price_gods = models.FloatField('Card price $GODS', default = 999)
	card_price_dollar = models.FloatField('Card price dollars USA', default = 999)
	card_img_link = models.CharField('Card IMG link', max_length = 100, default = "None")

	def __str__(self):
		return '{0}{1}{2}{3}'.format(str(self.card_nft_number), " (", str(self.card_name), ")")

class Round(models.Model):
	round_card = models.ForeignKey(Card, on_delete = models.CASCADE)
	round_id = models.IntegerField('Round id')
	round_num_tickets = models.IntegerField('Round number of tickets')
	round_tickets_bought = models.IntegerField('Round tickets bought', default = 0)
	round_winner = models.ForeignKey(Player, on_delete = models.SET_DEFAULT, default = "0x0")
	round_active = models.BooleanField('Round active', default = True)
	round_proof_result = models.IntegerField('Random result', default = 0)
	round_proof_random = models.TextField('Random proof random', default = "")
	round_proof_signature = models.TextField('Random proof signature', default = "")
	round_name = models.CharField('Round name', max_length = 100, default = str(round_id))
	round_transfer_proof = models.CharField('Proof of transfer prize', max_length = 100, default = "None")

	def __str__(self):
		return '{0}{1}{2}{3}{4}{5}'.format(self.round_name, 
			"round [", str(self.round_tickets_bought), " / ", str(self.round_num_tickets), "]")

class Ticket(models.Model):
	ticket_id = models.IntegerField('Ticket id')
	ticket_owner = models.ForeignKey(Player, on_delete = models.SET_DEFAULT, default = "0x0")
	ticket_round = models.ForeignKey(Round, on_delete = models.CASCADE)
	ticket_number = models.IntegerField('Ticket number')
	ticket_price_gods = models.FloatField('Ticket price $GODS')
	ticket_price_eth = models.FloatField('Ticket price ETH')
	ticket_won = models.BooleanField('This ticket won', default = False)

	def __str__(self):
		return '[{0}] {1}{2}{3}'.format(self.ticket_id, str(self.ticket_number), 
			" ticket for round #" , str(self.ticket_round))